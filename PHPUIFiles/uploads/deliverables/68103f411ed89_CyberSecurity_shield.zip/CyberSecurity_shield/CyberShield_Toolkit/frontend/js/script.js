


//JS FOR DASHBOARD.HTML
// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });
  
  // Fade-in animation for sections
  const sections = document.querySelectorAll('section');
  
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.1 });
  
  sections.forEach(section => {
    observer.observe(section);
  });


  // Phishing Detection - URL Scanner
document.getElementById('scanUrlBtn').addEventListener('click', () => {
    const url = document.getElementById('urlInput').value;
    const resultDiv = document.getElementById('urlResult');
  
    // Simulate URL scanning (replace with actual API call)
    if (url.includes('phishing')) {
      resultDiv.innerHTML = `<p class="status-danger">Malicious URL Detected!</p>`;
    } else {
      resultDiv.innerHTML = `<p class="status-success">URL is Safe.</p>`;
    }
  });
  
  // Phishing Detection - Email Analyzer
  document.getElementById('analyzeEmailBtn').addEventListener('click', () => {
    const emailContent = document.getElementById('emailInput').value;
    const resultDiv = document.getElementById('emailResult');
  
    // Simulate email analysis (replace with actual logic)
    if (emailContent.includes('urgent') || emailContent.includes('password')) {
      resultDiv.innerHTML = `<p class="status-danger">Phishing Email Detected!</p>`;
    } else {
      resultDiv.innerHTML = `<p class="status-success">Email is Safe.</p>`;
    }
  });

  // MITM Detection - Network Traffic Monitor
document.getElementById('startMonitorBtn').addEventListener('click', () => {
    const trafficLog = document.getElementById('trafficLog');
    const alertsLog = document.getElementById('alertsLog');
  
    // Simulate network traffic monitoring
    trafficLog.innerHTML = `
      <p>192.168.1.1 → 192.168.1.2: HTTP Request</p>
      <p>192.168.1.2 → 192.168.1.1: HTTP Response</p>
      <p>192.168.1.3 → 192.168.1.1: ARP Request</p>
    `;
  
    // Simulate suspicious activity detection
    alertsLog.innerHTML = `
      <p class="status-warning">Suspicious ARP activity detected from 192.168.1.3.</p>
    `;
  });


  // Email Hijacking - Header Analyzer
document.getElementById('analyzeHeaderBtn').addEventListener('click', () => {
    const emailHeaders = document.getElementById('emailHeaderInput').value;
    const resultDiv = document.getElementById('headerResult');
  
    // Simulate email header analysis (replace with actual logic)
    if (emailHeaders.includes('spf=fail') || emailHeaders.includes('dkim=fail')) {
      resultDiv.innerHTML = `<p class="status-danger">Email Hijacking Detected!</p>`;
    } else {
      resultDiv.innerHTML = `<p class="status-success">Email Headers are Authentic.</p>`;
    }
  });
  
  // Email Hijacking - SPF/DKIM/DMARC Validation
  document.getElementById('validateDomainBtn').addEventListener('click', () => {
    const domain = document.getElementById('domainInput').value;
    const resultDiv = document.getElementById('validationResult');
  
    // Simulate domain validation (replace with actual API call)
    if (domain === 'example.com') {
      resultDiv.innerHTML = `
        <p class="status-success">SPF: Pass</p>
        <p class="status-success">DKIM: Pass</p>
        <p class="status-success">DMARC: Pass</p>
      `;
    } else {
      resultDiv.innerHTML = `
        <p class="status-danger">SPF: Fail</p>
        <p class="status-danger">DKIM: Fail</p>
        <p class="status-danger">DMARC: Fail</p>
      `;
    }
  });




  // Malware Analysis - File Upload and Scan
document.getElementById('scanFileBtn').addEventListener('click', () => {
    const fileInput = document.getElementById('fileInput');
    const fileResult = document.getElementById('fileResult');
    const scanResults = document.getElementById('scanResults');
    const behaviorAnalysis = document.getElementById('behaviorAnalysis');
  
    if (fileInput.files.length === 0) {
      fileResult.innerHTML = `<p class="status-warning">Please select a file to scan.</p>`;
      return;
    }
  
    const file = fileInput.files[0];
    const fileName = file.name;
  
    // Simulate file scanning (replace with actual API call)
    if (fileName.includes('malware')) {
      fileResult.innerHTML = `<p class="status-danger">Malicious File Detected!</p>`;
      scanResults.innerHTML = `
        <p><strong>File Name:</strong> ${fileName}</p>
        <p><strong>Status:</strong> <span class="status-danger">Malicious</span></p>
        <p><strong>Threat Type:</strong> Trojan</p>
      `;
      behaviorAnalysis.innerHTML = `
        <p><strong>Behavioral Insights:</strong></p>
        <ul>
          <li>Attempted to modify registry keys.</li>
          <li>Initiated unauthorized network connections.</li>
        </ul>
      `;
    } else {
      fileResult.innerHTML = `<p class="status-success">File is Clean.</p>`;
      scanResults.innerHTML = `
        <p><strong>File Name:</strong> ${fileName}</p>
        <p><strong>Status:</strong> <span class="status-success">Clean</span></p>
      `;
      behaviorAnalysis.innerHTML = `<p>No suspicious behavior detected.</p>`;
    }
  });


  // Injection Attack Detection - Input Testing
document.getElementById('testInputBtn').addEventListener('click', () => {
    const input = document.getElementById('inputTest').value;
    const inputResult = document.getElementById('inputResult');
    const testLogs = document.getElementById('testLogs');
  
    // Simulate input testing (replace with actual logic)
    if (input.includes(';') || input.includes('<script>') || input.includes('1=1')) {
      inputResult.innerHTML = `<p class="status-danger">Vulnerable Input Detected!</p>`;
      testLogs.innerHTML = `
        <p><strong>Input:</strong> ${input}</p>
        <p><strong>Result:</strong> <span class="status-danger">Vulnerable</span></p>
        <hr>
        ${testLogs.innerHTML}
      `;
    } else {
      inputResult.innerHTML = `<p class="status-success">Input is Safe.</p>`;
      testLogs.innerHTML = `
        <p><strong>Input:</strong> ${input}</p>
        <p><strong>Result:</strong> <span class="status-success">Safe</span></p>
        <hr>
        ${testLogs.innerHTML}
      `;
    }
  });


  function scanPhishing() {
    const url = document.getElementById('urlInput').value;
    const emailContent = document.getElementById('emailInput').value;

    fetch('/phishing/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url, email_content: emailContent })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('urlResult').innerText = `URL Result: ${data.result}`;
        document.getElementById('emailResult').innerText = `Email Result: ${data.result}`;
    })
    .catch(error => console.error('Error:', error));
}

function scanMITM() {
  const networkData = document.getElementById('trafficLog').innerText;

  fetch('/mitm/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ network_data: networkData })
  })
  .then(response => response.json())
  .then(data => {
      document.getElementById('alertsLog').innerText = `Alerts: ${data.result}`;
  })
  .catch(error => console.error('Error:', error));
}

function scanEmail() {
  const emailHeaders = document.getElementById('emailHeaderInput').value;

  fetch('/email/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email_headers: emailHeaders })
  })
  .then(response => response.json())
  .then(data => {
      document.getElementById('headerResult').innerText = `Result: ${data.result}`;
  })
  .catch(error => console.error('Error:', error));
}

function scanMalware() {
  const fileInput = document.getElementById('fileInput');
  const file = fileInput.files[0];

  const formData = new FormData();
  formData.append('file', file);

  fetch('/malware/scan', {
      method: 'POST',
      body: formData
  })
  .then(response => response.json())
  .then(data => {
      document.getElementById('fileResult').innerText = `Result: ${data.result}`;
  })
  .catch(error => console.error('Error:', error));
}


function scanInjection() {
  const userInput = document.getElementById('inputTest').value;

  fetch('/injection/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ input: userInput })
  })
  .then(response => response.json())
  .then(data => {
      document.getElementById('inputResult').innerText = `Result: ${data.result}`;
  })
  .catch(error => console.error('Error:', error));
}