from scapy.all import sniff, ARP

def detect_mitm():
    def packet_callback(packet):
        if packet.haslayer(ARP) and packet[ARP].op == 2:  # ARP response
            print(f"Possible MITM attack: {packet[ARP].hwsrc} is spoofing {packet[ARP].psrc}")

    sniff(prn=packet_callback, filter="arp", store=0)