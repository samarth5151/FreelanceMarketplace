import dkim 
import spf 

def validate_email(headers):
    dkim_result = dkim.verify(headers)
    spf_result = spf.check2(headers.get("From"), headers.get("Received-SPF"))
    return dkim_result, spf_result