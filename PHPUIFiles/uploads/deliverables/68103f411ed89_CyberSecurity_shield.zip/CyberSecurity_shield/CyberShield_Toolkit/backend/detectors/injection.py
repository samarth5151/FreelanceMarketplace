import re

def detect_injection(input):
    sql_pattern = re.compile(r"(';|--|1=1)", re.IGNORECASE)
    xss_pattern = re.compile(r"(<script>|alert\()", re.IGNORECASE)
    if sql_pattern.search(input) or xss_pattern.search(input):
        return "Vulnerable"
    return "Safe"