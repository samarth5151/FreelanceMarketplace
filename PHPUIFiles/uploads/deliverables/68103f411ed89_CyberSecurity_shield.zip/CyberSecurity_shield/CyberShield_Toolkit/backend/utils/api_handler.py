
import requests

# Google Safe Browsing API
def check_url_google_safe_browsing(url):
    api_key = "AIzaSyBDHEpmNCeFDsucsBRNqzywgMrSMbOH-G4"
    api_url = f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={api_key}"
    payload = {
        "client": {"clientId": "cybershield", "clientVersion": "1.0"},
        "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": url}],
        },
    }
    response = requests.post(api_url, json=payload)
    return response.json()

# VirusTotal API
def scan_file_virustotal(file_path):
    api_key = "377c519b009ed2575e779be41edc49fe81a9ad246dfcbbfe250ebcb6ef73e92c"
    url = "https://www.virustotal.com/vtapi/v2/file/scan"
    files = {"file": open(file_path, "rb")}
    params = {"apikey": api_key}
    response = requests.post(url, files=files, params=params)
    return response.json()