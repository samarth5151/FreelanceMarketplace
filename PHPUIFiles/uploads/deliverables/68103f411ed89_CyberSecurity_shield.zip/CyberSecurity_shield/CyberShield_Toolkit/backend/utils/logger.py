import logging
from datetime import datetime
from database.models import db, Log

def log_action(user_id, module, action, details=None):
    """
    Logs user actions to the database.
    """
    try:
        new_log = Log(
            UserID=user_id,
            Module=module,
            Action=action,
            Details=details,
            Timestamp=datetime.utcnow()
        )
        db.session.add(new_log)
        db.session.commit()
    except Exception as e:
        logging.error(f"Failed to log action: {e}")