import re

def sanitize_input(input):
    """
    Sanitizes user input to prevent SQL, XSS, and code injection.
    """
    # Remove SQL injection patterns
    input = re.sub(r"(';|--|1=1)", "", input, flags=re.IGNORECASE)
    # Remove XSS patterns
    input = re.sub(r"(<script>|alert\()", "", input, flags=re.IGNORECASE)
    return input