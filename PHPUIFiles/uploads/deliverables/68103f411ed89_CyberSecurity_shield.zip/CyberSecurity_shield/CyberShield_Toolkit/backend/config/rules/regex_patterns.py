SQL_INJECTION_PATTERN = r"(';|--|1=1)"
XSS_PATTERN = r"(<script>|alert\()"