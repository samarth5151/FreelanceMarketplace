import os

class Config:
    # Google Safe Browsing API Key
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "AIzaSyBDHEpmNCeFDsucsBRNqzywgMrSMbOH-G4")
    
    # VirusTotal API Key
    VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "377c519b009ed2575e779be41edc49fe81a9ad246dfcbbfe250ebcb6ef73e92c")
    
    # Database URI
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URI", "sqlite:///cybershield.db")
    
    # Other settings
    DEBUG = True