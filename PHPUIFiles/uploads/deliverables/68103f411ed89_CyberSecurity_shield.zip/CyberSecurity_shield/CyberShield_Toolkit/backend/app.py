from flask import Flask, jsonify, request
from flask_cors import CORS
from database.models import db, User, Log, PhishingScan, MITMScan, EmailScan, MalwareScan, InjectionScan
from detectors.phishing import check_url
from detectors.mitm import detect_mitm
from detectors.email_hijacking import validate_email
from detectors.malware import scan_file
from detectors.injection import detect_injection

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///C:/xampp/htdocs/CyberSecurity_shield/CyberShield_Toolkit/backend/database/cybershield.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Create database tables (if they don't exist)
with app.app_context():
    db.create_all()

# Helper function to log actions
def log_action(user_id, module, action, details=None):
    """
    Logs user actions to the database.
    """
    new_log = Log(UserID=user_id, Module=module, Action=action, Details=details)
    db.session.add(new_log)
    db.session.commit()

# Home Route
@app.route('/')
def home():
    return "CyberShield Toolkit Backend"

# Phishing Detection Endpoint
@app.route('/phishing/scan', methods=['POST'])
def phishing_scan():
    """
    Endpoint to scan URLs and email content for phishing attempts.
    """
    data = request.json
    url = data.get('url')
    email_content = data.get('email_content')

    # Perform phishing detection
    result = check_url(url)  # Use the phishing detection module

    # Save result to database
    new_scan = PhishingScan(UserID=1, URL=url, EmailContent=email_content, Result=result)
    db.session.add(new_scan)
    db.session.commit()

    # Log the action
    log_action(user_id=1, module="Phishing", action="Scan", details=f"URL: {url}, Email Content: {email_content}")

    return jsonify({"result": result})

# MITM Detection Endpoint
@app.route('/mitm/scan', methods=['POST'])
def mitm_scan():
    """
    Endpoint to detect MITM and IP spoofing attacks.
    """
    data = request.json
    network_data = data.get('network_data')

    # Perform MITM detection
    result = detect_mitm(network_data)  # Use the MITM detection module

    # Save result to database
    new_scan = MITMScan(UserID=1, NetworkData=network_data, Result=result)
    db.session.add(new_scan)
    db.session.commit()

    # Log the action
    log_action(user_id=1, module="MITM", action="Scan", details=f"Network Data: {network_data}")

    return jsonify({"result": result})

# Email Hijacking Detection Endpoint
@app.route('/email/scan', methods=['POST'])
def email_scan():
    """
    Endpoint to detect email hijacking attempts.
    """
    data = request.json
    email_headers = data.get('email_headers')

    # Perform email hijacking detection
    dkim_result, spf_result = validate_email(email_headers)  # Use the email hijacking detection module
    result = "Authentic" if dkim_result and spf_result else "Hijacked"

    # Save result to database
    new_scan = EmailScan(UserID=1, EmailHeaders=email_headers, SPFResult=spf_result, DKIMResult=dkim_result, Result=result)
    db.session.add(new_scan)
    db.session.commit()

    # Log the action
    log_action(user_id=1, module="Email", action="Scan", details=f"Email Headers: {email_headers}")

    return jsonify({"result": result})

# Malware Analysis Endpoint
@app.route('/malware/scan', methods=['POST'])
def malware_scan():
    """
    Endpoint to scan files for malware and spyware.
    """
    file = request.files['file']
    file_name = file.filename
    file_hash = "sha256_hash_here"  # Replace with actual hash calculation

    # Perform malware analysis
    result = scan_file(file)  # Use the malware analysis module

    # Save result to database
    new_scan = MalwareScan(UserID=1, FileName=file_name, FileHash=file_hash, Result=result)
    db.session.add(new_scan)
    db.session.commit()

    # Log the action
    log_action(user_id=1, module="Malware", action="Scan", details=f"File: {file_name}")

    return jsonify({"result": result})

# Injection Attack Detection Endpoint
@app.route('/injection/scan', methods=['POST'])
def injection_scan():
    """
    Endpoint to detect SQL, XSS, and code injection attacks.
    """
    data = request.json
    user_input = data.get('input')

    # Perform injection attack detection
    result = detect_injection(user_input)  # Use the injection detection module

    # Save result to database
    new_scan = InjectionScan(UserID=1, Input=user_input, Result=result)
    db.session.add(new_scan)
    db.session.commit()

    # Log the action
    log_action(user_id=1, module="Injection", action="Scan", details=f"Input: {user_input}")

    return jsonify({"result": result})

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)