from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    """
    Represents a user in the system.
    """
    UserID = db.Column(db.Integer, primary_key=True)
    Username = db.Column(db.String(50), unique=True, nullable=False)
    PasswordHash = db.Column(db.String(100), nullable=False)
    Email = db.Column(db.String(100), unique=True, nullable=False)
    CreatedAt = db.Column(db.DateTime, default=db.func.current_timestamp())

    # Relationships
    logs = db.relationship('Log', backref='user', lazy=True)
    phishing_scans = db.relationship('PhishingScan', backref='user', lazy=True)
    mitm_scans = db.relationship('MITMScan', backref='user', lazy=True)
    email_scans = db.relationship('EmailScan', backref='user', lazy=True)
    malware_scans = db.relationship('MalwareScan', backref='user', lazy=True)
    injection_scans = db.relationship('InjectionScan', backref='user', lazy=True)

class Log(db.Model):
    """
    Represents a log entry for user activities.
    """
    LogID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('user.UserID'), nullable=False)
    Module = db.Column(db.String(50), nullable=False)
    Action = db.Column(db.String(50), nullable=False)
    Details = db.Column(db.Text)
    Timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

class PhishingScan(db.Model):
    """
    Represents a phishing scan result.
    """
    ScanID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('user.UserID'), nullable=False)
    URL = db.Column(db.Text)
    EmailContent = db.Column(db.Text)
    Result = db.Column(db.String(50), nullable=False)
    Timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

class MITMScan(db.Model):
    """
    Represents an MITM and IP spoofing scan result.
    """
    ScanID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('user.UserID'), nullable=False)
    NetworkData = db.Column(db.Text)
    Result = db.Column(db.String(50), nullable=False)
    Timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

class EmailScan(db.Model):
    """
    Represents an email hijacking scan result.
    """
    ScanID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('user.UserID'), nullable=False)
    EmailHeaders = db.Column(db.Text)
    SPFResult = db.Column(db.String(50))
    DKIMResult = db.Column(db.String(50))
    DMARCResult = db.Column(db.String(50))
    Result = db.Column(db.String(50), nullable=False)
    Timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

class MalwareScan(db.Model):
    """
    Represents a malware and spyware scan result.
    """
    ScanID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('user.UserID'), nullable=False)
    FileName = db.Column(db.String(100), nullable=False)
    FileHash = db.Column(db.String(64), nullable=False)  # SHA-256 hash
    Result = db.Column(db.String(50), nullable=False)
    BehavioralAnalysis = db.Column(db.Text)
    Timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

class InjectionScan(db.Model):
    """
    Represents an injection attack scan result.
    """
    ScanID = db.Column(db.Integer, primary_key=True)
    UserID = db.Column(db.Integer, db.ForeignKey('user.UserID'), nullable=False)
    Input = db.Column(db.Text, nullable=False)
    Result = db.Column(db.String(50), nullable=False)
    Timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())