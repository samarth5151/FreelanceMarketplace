package com.example.TecFresh.Shopkeeper;

public class receivedOrders {
}
